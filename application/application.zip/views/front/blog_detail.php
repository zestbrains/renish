<div class="blog-parent">
  <div class="container">
    <div class="row">
      <div class="blog-main-left col-sm-8 col-md-8 col-lg-8 col-xs-12">
        <div class="blog-item">
          <div class="blog-inner">
            <div class="blog-img"> <a href="javascript:void(0)"> <img src="<?php echo ASSETS_URL; ?>/uploads/blogitemimg.jpg"> </a> </div>
            <div class="blog-name"><a href="javascript:void(0)"> Blog name </a> </div>
            <div class="blog-actions">
              <ul>
                <li><a href="javascript:void(0)"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i>Likes<span>25</span></a></li>
                <li> <a href="javascript:void(0)"><i class="fa fa-comments-o" aria-hidden="true"></i>Comments</a></li>
                <l=i><a href="javascript:void(0)"><i class="fa fa-calendar" aria-hidden="true"></i>Feb 26, 2017</a></li>
              </ul>
            </div>
            <div class="blog-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
              <ul>
                <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
                <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
                <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
              </ul>
             </div>
          </div>
        </div>
        <div class="comments">
        <div class="blgg-title">LEAVE YOUR COMMENT</div>
    		<form>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12">
            	<label>Your Name*</label>
                <input type="text">
                <label>Your Email*</label>
                <input type="email">
                <label>Your Webpage</label>
                <input type="text">
            </div>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12">
            <label>Your Comment*</label>
            <textarea></textarea>
				<input type="submit" value="SUBMIT YOUR COMMENT">
                        </div>
            </form>
        </div>
      </div>
      <div class="blog-main-right col-sm-4 col-md-4 col-lg-4 col-xs-12">
        <div class="recent-posts">
          <div class="blg-title">RECENT POSTS</div>
          <ul>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>U.S. Road Trip Destinations and Tips</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Driving in Icy Weather</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Winter Driving Crash Course</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Keeping Kids Safe in (and Around) Your Car</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Auto Glass Repair</a></li>
          </ul>
        </div>
        <div class="catagoriess">
          <div class="blg-title">CATEGORIES</div>
          <ul>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>U.S. Road Trip Destinations and Tips</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Driving in Icy Weather</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Winter Driving Crash Course</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Keeping Kids Safe in (and Around) Your Car</a></li>
            <li><a href="#"><i class="fa fa-chevron-right"><i></i></i>Auto Glass Repair</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
