
<div class="container">
            <div class="row ">
               <section id="page-body" class="notoppadding">
    
        <div class="fullwidth-section fullheight page-not-found">
        	<div class="fullwidth-content wrapper-small align-center">
                <div class="col-lg-6">
					<h1 class="error-404"><strong>404</strong></h1>
				</div>
				<div class="col-lg-6">
					<img src="<?php echo ASSETS_URL; ?>/uploads/404-car.png"/>
				</div>
                <h3><strong>The Page you were looking for,<br>couldn't be found.</strong></h3>
                <div class="spacer-medium"></div>
                <a href="<?php echo DOMAIN_URL; ?>/home" class="sr-button button-small button-4 rounded">Back to homepage</a>
        	</div>
        </div> <!-- END .fullwidth-section -->
                    
 	</section>
                           
            </div>
         </div>